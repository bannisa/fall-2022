#include <stdlib.h>
#include "IntegerArray.h"


IntegerArray::IntegerArray()
{
	maxSize = initialSize;
	curSize = 0;
	data = (int*)malloc(maxSize * sizeof(int));
}

IntegerArray::~IntegerArray()
{
	free(data);
}

int IntegerArray::getSize()
{
	return curSize;
}

int IntegerArray::getValue(int position)
{
	if ( position >= 0 && position < curSize )
	{
		return data[position];
	}
	else return -1;
}

int IntegerArray::setValue(int position, int value)
{
	if ( position >= 0 && position < curSize )
	{
		data[position] = value;
		return 0;
	}
	else return -1;
}

float IntegerArray::getAverage()
{
	int total = 0;
	
	for (int i = 0; i < curSize; i++)
	{
		total += data[i]; 
	}

	return  total/(float)curSize;
}

int IntegerArray::getMax()
{
	int max = INT_MAX;
	
	for (int i = 0; i < curSize; i++)
	{
		if ( data[i] > max )
			max = data[i]; 
	}

	return  max;
}

int IntegerArray::getMin()
{
	int min = INT_MIN;
	
	for (int i = 0; i < curSize; i++)
	{
		if ( data[i] < min )
			min = data[i]; 
	}
	return  min;
}

int IntegerArray::remove(int position)
{
	if ( position >= curSize )
		return -1;
	
	for (int i = position + 1; i < curSize; i++)
	{
		data[i-1] = data[i];
	}
	curSize--;
	return curSize;
}

int IntegerArray::insert(int position, int value)
{
	int * dataCopy = NULL;
	
	if ( position > curSize)
		return -1;
	if ( curSize == maxSize )
	{
		dataCopy = (int*) malloc( maxSize * 2 * sizeof(int) );
		if (dataCopy == NULL)
			return -1;
		maxSize = maxSize * 2;

		for (int i = 0; i < curSize; i++)
		{
			dataCopy[i] = data[i];
		}
		free(data);
		data = dataCopy; 
	}
	
	for (int i = curSize; i > position; i--)
	{
		data[i] = data[i-1];
	}
	data[position] = value;

	curSize++;
	return curSize;
}