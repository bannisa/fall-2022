#include "IntegerArray.h"
 
int	main()
{
   
	IntegerArray* array1 = NULL;
	IntegerArray* array2 = NULL;

	array1 = new IntegerArray();
	array2 = new IntegerArray();

	for (int i = 0; i < 40; i++)
		array1->insert(i,i);

	array1->remove(3);

	for(int i = 0; i < array1->getSize(); i++)
		printf( "%d\n", array1->getValue(i));

	array1->insert(3,3);

	for(int i = 0; i < array1->getSize(); i++)
		printf( "%d\n", array1->getValue(i));

	for (int i = 0; i < 40; i++)
		array2->insert(i,8);
	for(int i = 0; i < array2->getSize(); i++)
		printf( "%d\n", array2->getValue(i));


	delete array1;
	delete array2;

	char c;
	scanf("%c", &c);
	return 0;


}