class IntegerArray
{
private:
	int * data;
	int maxSize;
	int curSize;
	static const int initialSize = 40;

public:
	IntegerArray();
	~IntegerArray();
	int getSize();
	int setValue(int position, int value);
	int getValue(int position);

	float getAverage();
	int getMax();
	int getMin();
	int insert(int position, int value);
	int remove(int position);

};