// BasicCalculator.cpp : Simple program that reads two numbers from the keyboard and performs basic arithmetic operations with them.
//

#include <stdio.h> 
#include "MathLibrary.h"
//float performMathOperation(int num1, int num2, char operation);

int main()
{
	int num1 = 0, num2 = 0;
	float result = 0;
	char operation = '+', tmp, answer = 'y';

	while (answer == 'y')
	{

		//The function scanf is going to modify the contents of variables num1 and num2 in the main program
		//so we need to pass them by reference and not by value ie we need to pass their address instead of their contents
		printf("Please enter first number\n");
		scanf("%d", &num1);
		printf("Please enter second number\n");
		scanf("%d", &num2);
		printf("Please enter operation\n");
		//We need this statement to read the new line(enter) character left in the keyboard buffer
		scanf("%c", &tmp);
		scanf("%c", &operation);
		//clear keyboard buffer
	    scanf("%c", &tmp);

		/*printf("The numbers are %d and %d and the operation is %c\n",
		    num1, num2, operation);*/
	
		//This code is replaced below by calls to a subroutine/method
		/*if ( operation == '+')
			result = num1 + num2;
		else if (operation == '-')
			result = num1 - num2;
		else if (operation == 'x')
			result = num1 * num2;
		else if (operation == '/' && num2 != 0)
			result = (float)num1 / num2;
		else printf("Invalid operation!!\n");*/

		//result = performMathOperation(num1, num2, operation);
		performMathOperation(num1,num2,operation,&result);
		printf("The result is: %.2f\n", result);

		printf("Do you want to try again?(y/n)\n");
		scanf("%c", &answer);
		//clear keyboard buffer
	    scanf("%c", &tmp);
	}
	return 0;

}