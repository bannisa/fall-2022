//This is the .h file for the math library containing the signatures for all functions
float performMathOperation(int num1, int num2, char operation);
void performMathOperation(int num1, int num2, char operation, float* result);