//In this file we are storing some functions/methods that can be called to perform mathematical
//operations


/*This method receives two integer numbers and a character representing an operation and
returns the result of performing the operation with the numbers*/
float performMathOperation(int num1, int num2, char operation)
{
	float result = 0;

	if ( operation == '+')
		result = num1 + num2;
	else if (operation == '-')
		result = num1 - num2;
	else if (operation == 'x')
		result = num1 * num2;
	else if (operation == '/' && num2 != 0)
		result = (float)num1 / num2; //We should cast at least one of the integer variables to float to avoid losing precision

	return result;
}

/*This method receives two integer numbers, a character representing an operation and the address of 
a memory location belonging to the calling program where the result of performing the operation with the numbers should be stored */
void performMathOperation(int num1, int num2, char operation, float* result)
{
	if ( operation == '+')
		*result = num1 + num2;
	else if (operation == '-')
		*result = num1 - num2;
	else if (operation == 'x')
		*result = num1 * num2;
	else if (operation == '/' && num2 != 0)
		*result = (float)num1 / num2;
}