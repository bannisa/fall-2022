woman(nicole). 
woman(angelina). 
woman(marissa). 
    
loves(nicole,roger). 
loves(angelina,mark). 
loves(prince,princess). 
loves(mark,angelina).
loves(mickey,minnie).

jealous(X,Y) :- loves(X,Z),loves(Y,Z).