woman(megan). 
woman(wanda). 
woman(martha). 
likesKoolAid(megan). 
drinksBeer.