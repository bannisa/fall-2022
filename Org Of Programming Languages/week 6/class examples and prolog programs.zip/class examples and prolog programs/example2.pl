smart(mark). 
doesHomework(alice). 
doesHomework(mark):-  smart(mark). 
getsGoodGrade(alice):-  doesHomework(alice). 
getsGoodGrade(mark):-  doesHomework(mark).