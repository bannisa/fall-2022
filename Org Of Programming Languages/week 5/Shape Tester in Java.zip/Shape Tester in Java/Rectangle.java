/**
 *
 * @author Steve
 */
public class Rectangle extends Shape
{
    double width;
    double length;
    
    public Rectangle(double width, double length)
    {
        super();
        this.width = width;
        this.length = length;
    }
    
    public String getType()
    {
        return "Rectangle";
    }
    
    public double area()
    {
        return width * length;
    }
    
}
