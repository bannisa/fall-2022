/**
 *
 * @author Steve
 */
public abstract class Shape
{
    public Shape()
    {
        
    }
    
    public String getType()
    {
        return "";
    }
    
    public double area()
    {
        return 0;
    }
    
    public void print()
    {
        System.out.println("The area of the " + getType() + " is: " + area());
    }
    
}
