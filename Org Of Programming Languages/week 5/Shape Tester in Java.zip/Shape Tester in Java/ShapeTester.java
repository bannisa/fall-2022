import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Steve
 */
public class ShapeTester
{
    public static void main(String[] args)
    {
//        Shape shape1 = new Rectangle(3,7);
//        Shape shape2 = new Circle(8);
//        Shape shape3 = new Triangle(20,4);
//        
//        System.out.println( "The area of shape1 is:" + shape1.area());
//        System.out.println( "The area of shape2 is:" + shape2.area());
//        System.out.println( "The area of shape3 is:" + shape3.area());
//        
//        shape1.print();
//        shape2.print();
//        shape3.print();
        
        ArrayList<Shape> shapes = new ArrayList<Shape>();
        char answer = 'y';
        Scanner scan = new Scanner(System.in);
        
        while ( answer != 'n')
        {
            System.out.println("Shape creation application");
            System.out.println("1 - Triangle");
            System.out.println("2 - Rectangle");
            System.out.println("3 - Circle");
            int choice = scan.nextInt();
            Shape tmpShape = null;
            
            switch (choice)
            {
                case 1:
                    System.out.println("Enter base: ");
                    double base = scan.nextDouble();
                    System.out.println("Enter height: ");
                    double height = scan.nextDouble();
                    tmpShape = new Triangle(base,height);
                    break;
                case 2:
                    
                    System.out.println("Enter width: ");
                    double width = scan.nextDouble();
                    System.out.println("Enter length: ");
                    double length = scan.nextDouble();
                    tmpShape = new Rectangle(width,length);
                    break;
                case 3:
                    System.out.println("Enter radius: ");
                    double radius = scan.nextDouble();
                    tmpShape = new Circle(radius);
                    break;
            }
            shapes.add(tmpShape);
            
            System.out.println("Create another shape?");
            answer = scan.next().charAt(0); 
          
        }
        
        //Display the information of all shapes in the array
        for (int i = 0; i < shapes.size(); i++)
            shapes.get(i).print();
            
    }
}
