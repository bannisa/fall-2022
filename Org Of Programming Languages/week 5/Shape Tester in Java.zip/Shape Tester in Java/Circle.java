/**
 *
 * @author Steve
 */
public class Circle extends Shape
{
    private double radius;
    private final double pi = 3.14;
    
    public Circle(double radius)
    {
        super();
        this.radius = radius; 
    }
    
    public String getType()
    {
        return "Circle";
    }
    
    public double area()
    {
        return pi * Math.pow(radius,2);
    }
    
}
