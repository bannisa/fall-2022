#include "Rectangle.h"
    
Rectangle::Rectangle(double width, double length)
{
    Shape();
    this->width = width;
    this->length = length;
}
    
const char* Rectangle::getType()
{
    return "Rectangle";
}
    
double Rectangle::area()
{
    return width * length;
}
    

