// ShapeTester.cpp : main project file.
#include "Rectangle.h"
#include "Circle.h"
#include "Triangle.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	
      /* Shape* shape1 = new Rectangle(3,7);
          Shape* shape2 = new Circle(8);
          Shape* shape3 = new Triangle(20,4);
		
          printf( "The area of shape1 is: %.2f\n", shape1->area());
          printf( "The area of shape2 is: %.2f\n", shape2->area());
          printf( "The area of shape3 is: %.2f\n", shape3->area());
        
          shape1->print();
          shape2->print();
          shape3->print();

          int ch = 'c';
          scanf("%c",&ch);*/
        
        int currentSize = 20;
        int count = 0;
        Shape** shapes = (Shape**)malloc(currentSize * sizeof(Shape*));
        char answer = 'y';
        int choice = 0;
        
        while ( answer != 'n')
        {
            printf("Shape creation application\n");
            printf("1 - Triangle\n");
            printf("2 - Rectangle\n");
            printf("3 - Circle\n");
            scanf("%d", &choice);
            Shape* tmpShape = NULL;
            
            switch (choice)
            {
                case 1:
                    printf("Enter base: \n");
                    double base;
	    scanf("%lf", &base);
                    printf("Enter height: \n");
                    double height;
	    scanf("%lf", &height);
                    tmpShape = new Triangle(base,height);
                    break;
                case 2:
                    printf("Enter width: \n");
                    double width;
	    scanf("%lf", &width);
                    printf("Enter length: \n");
                    double length;
	    scanf("%lf", &length);
                    tmpShape = new Rectangle(width,length);
                    break;
                case 3:
                    printf("Enter radius: \n");
                    double radius;
                    scanf("%lf", &radius);
                    tmpShape = new Circle(radius);
                    break;
            }
			
            if (count == currentSize)
            {
	 Shape** shapesCopy = (Shape**)malloc(currentSize * 2 * sizeof(Shape*));
	 memcpy(shapesCopy, shapes, sizeof(Shape*) * currentSize);
	 currentSize *= 2;
	 free(shapes);
	 shapes = shapesCopy;
            }
            shapes[count] = tmpShape;
            count++;
            
            printf("Create another shape?\n");
            char newLine;
            scanf("%c",&newLine); 
            scanf("%c",&answer); 
        }
        
        //Display the information of all shapes in the array
        for (int i = 0; i < count; i++)
            shapes[i]->print();

        //Deallocate memory
        for (int i = 0; i < count; i++)
            delete shapes[i];
		
		
        scanf("%d", &choice);
            
   
        return 0;
}
