#include "Shape.h"

class Circle : public Shape
{
private:
	double radius;
                static const double pi;
    
public:
	Circle(double radius);
                const char* getType();
                double area();
};