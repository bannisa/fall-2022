#include "Triangle.h"
    
Triangle::Triangle(double base, double height)
{
    Shape();
    this->base = base;
    this->height = height;
}
    
const char* Triangle::getType()
{
    return "Triangle";
}
    
double Triangle::area()
{
    return (base * height) / 2;
}
    

