float getAverage(int intArray[], int size);
int getMax(int intArray[], int size);
int getMin(int intArray[], int size);
int remove(int intArray[], int size, int elementIndex);
bool remove(int intArray[], int* size, int elementIndex);
bool insert(int** intArray, int* size, int* capacity, int position, int value);
