#include <stdlib.h>
#include "CQueue.h"
#include "Queue.h"
#include <stdio.h>
#pragma warning(disable : 4996)

bool resize(int** arrayPtr, int size, int* capacity, int* head, int* tail);

int pop(int* queueArray, int* size, int capacity, int* head)
{
	int result = 0;

	if ((*size) > 0) {
		result = queueArray[(*head)];
		(*size)--;
		*head = ((*head) + 1) % capacity;
	}

	return result;
}


bool push(int** queueArray, int toPush, int* size, int* capacity, int* head, int* tail) {
	
	bool result = false;


	if ((*size) < (*capacity)) {
		(*queueArray)[*tail] = toPush;
		(*size)++;
		if (*size == *capacity) {
			bool success = resize(queueArray, *size, capacity, head, tail);
			if (!success)
				return result;
		}
		else {
			(*tail) = ((*tail) + 1) % *capacity;
		}

		result = true;
	}

	return result;
}


bool resize(int** arrayPtr, int size, int* capacity, int* head, int* tail) {

	int scaleFactor = 2;

	bool result = false;

	int* tmpArray = (int*) malloc((*capacity * scaleFactor) * sizeof(int));
	if (tmpArray)
	{
		int tmp = *head;

		int i = 0;

		for (; tmp != (*tail); i++) { // copys everyone element untill the last one in the queue

			tmpArray[i] = (*arrayPtr)[tmp];

			tmp = (++tmp) % *capacity;
		}

		tmpArray[i] = (*arrayPtr)[tmp]; // copy the last element of the queue

		*head = 0;
		*tail = size;
		*capacity = (*capacity) * scaleFactor;

		free(*arrayPtr);

		(*arrayPtr) = tmpArray;

		result = true;
	}
	return result;
}



int peek(int* queueArray, int size, int capacity, int head, int tail) {
	
	int result = 0;

	if (size > 0) {
		result = queueArray[head];
	}

	return result;
}