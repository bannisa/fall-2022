#ifndef QUEUE_H
#define QUEUE_H

#include <stdlib.h>
#include <string.h>
#include <string>

template<typename T>
class Queue {

private:

	/*
	* Prerequisites: getSize() == getCapacity()
	* Arguments: None
	* Retruns: Creates a new "queue" and copies the current queue into it, frees the current queue.
	*			increases the capacity, and points the head, and tail to the new queue head an tail locations.
	*/
	bool resize() {
		bool success = false;

		T* tempArray = (T*) malloc(this->getCapacity() * this->scaleFactor * sizeof(T)); // Get memory from the heap.

		if (tempArray) { // If the memory allocation isn't NULL.
			
			this->end = this->getCapacity() - 1;

			int loc = this->start; // create a temp head location

			int tmp = 0; // start from zero in the new array

			for (; loc != this->end; tmp++) { // increment the location we're copying to in the new array until we're at the end element
				tempArray[tmp] = this->myArray[loc]; // copy the head of the old array, to a new head location in the new array.
				loc = (++loc) % this->size; // increment the location to copy inside to the next one.
			}

			tempArray[tmp] = this->myArray[loc]; //Copy the end element

			this->size *= this->scaleFactor; // Increment the size aka the capacity.
			this->start = 0; // The queues new head starts at the start of the array.
			this->end = this->inUse; // the end of the queue is at the number of elements of things on the queue. Due to offset from 0
			free(this->myArray); // free the old array memory. Note, we need a method to determine if T is a obj.
			this->myArray = tempArray; //Assign the new memory.
			success = true; // We're done !
		}

		return success;
	}

	//A array for used to hold the queue
	T* myArray;
	//The number of elements the queue can hold
	int size;
	//The length of the queue
	int inUse;
	//Head aka first thing to dequeue
	int start;
	//Next position in the queue to place a element
	int end;

	/*Internal scale factor for the queue when it's resized
	*	The new queue will be size * scaleFactor in size
	**/
	static const int scaleFactor{ 2 };

	//Defalut size for the queue if none is specified
	static const int defaultCapacity{ 2 };

public:

	/*
	* Prerequisites: Types must be basic data types, float, double, int, char. No classes.
	* Arguments: A the capacity for the queue that is greater than 1. Defalut capacity is 2.
	* Retruns: A new queue object. 
	* Throws: -1 if memory wasn't able to be allocated in the heap
	*/
	explicit Queue(int initlizedCapacity = defaultCapacity)
	{
		if (initlizedCapacity > 1) {
			this->size = initlizedCapacity;
			this->myArray = (T*) malloc(initlizedCapacity * sizeof(T));
		}
		else {
			this->size = Queue::defaultCapacity;
			this->myArray = (T*) malloc(Queue::defaultCapacity * sizeof(T));
		}
		if (!this->myArray) {
			throw - 1;
		}

		this->start = 0;
		this->end = 0;
		inUse = 0;
	}

	~Queue() { free(myArray); }
	
	/*
	* Prerequisites: None
	* Arguments: None
	* Retruns: The current capacity of this queue.
	*/
	inline int getCapacity() { return this->size; }

	/*
	* Prerequisites: None
	* Arguments: None
	* Retruns: True if the queue is empty, else false
	*/
	inline bool isEmpty() { return this->inUse == 0; }

	/*
	* Prerequisites: None.
	* Arguments: None.
	* Retruns: The number of elements in the queue.
	*/
	inline int getSize() { return this->inUse; }

	/*
	* Prerequisites: isEmpty() must return false for this method to execute properly.
	* Arguemnts: None
	* Returns: The head element of the queue if one exists, else error
	*/
	T pop()
	{
		T toReturn;

		if (!this->isEmpty()) {
			toReturn = this->myArray[start];

			this->start = ++this->start % this->getCapacity();
			this->inUse--;
		}

		return toReturn;
	}

	/*
	* Prerequisites: isEmpty() must return false for this function to run properly.
	* Arguments: None
	* Retruns: The head, first element in the queue if one exists, else it will error.
	*/
	T peek() {
		T toReturn;

		if (!this->isEmpty())
			toReturn = this->myArray[this->start];

		return toReturn;
	}

	/*
	* Prerequisites: None
	* Arguments: toQueue, item to place in the back of the queue.
	* Retruns: True if the item was placed, else false. 
				If the queue cannot be resized due to lack of memory then it will return false as well.
	*/
	bool push(T toQueue)
	{

		if (this->getSize() == this->getCapacity()) // If we're within the bounds of the array.
			if (!this->resize()) // If the resize didn't work, return false.
				return false;

		this->myArray[this->end] = toQueue; // assign the item to the end of the queue.
		this->inUse++; // incro the number of things in the queue.
		this->end = ++this->end % this->getCapacity(); // increment the the head, next element of the queue

		return true;
	}

	/*
	* Prerequisites: The elements within the queue must be able to be converted using the string::to_string() method.
	* Arguments: None
	* Retruns: A string obj representation of the items within the queue, in order from front to back
	*			using the string::to_string() method.
	*/
	std::string toString()
	{
		std::string result{ "" };

		if (this->getSize() > 0) {

			for (int i{ this->start }; i != this->end; i = ++i % this->getCapacity())
				result += std::to_string(this->myArray[i]);
		}

		return result;
	}
};

#endif // !Queue
