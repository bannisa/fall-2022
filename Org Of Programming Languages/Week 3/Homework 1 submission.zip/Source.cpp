#include "CQueue.h"
#include "Queue.h"
#include <stdio.h>
#include <stdlib.h>
#include <string>
#pragma warning(disable : 4996)

int main() {

	bool done = false;

	int userInput;
	char tmp;

	while (!done) {

		printf("Would you like to test the C(1) or C++(2) library or exit(3)?\n	Enter 1 or 2 or 3:");
		scanf("%d", &userInput);
		scanf("%c", &tmp);
		
		if (userInput == 1) {
			int capacity = 2;
			int size = 0;
			int tail = 0;
			int head = 0;

			int* userArray = (int*) malloc(capacity * sizeof(int));

			if (userArray)
				printf("Internal heap error, exiting option 1.\n\n");
			else {

				while (!done) {

					int userResponse;
					printf("Queue Status: size:%d, capacity:%d, head:%d, tail:%d", size, capacity, head, tail);
					printf("\nWould you like to quit(1), push(2), pop(3), peek(4), list the queue contents(5)?:");
					scanf("%d", &userResponse);
					scanf("%c", &tmp);

					if (userResponse == 1) {
						done = true;
					}
					else if (userResponse == 2) {
						printf("Enter a number to enqueue on the queue:");
						scanf("%d", &userResponse);
						scanf("%c", &tmp);


						bool success = push(&userArray, userResponse, &size, &capacity, &head, &tail);

						if (success) {
							printf("%d has been added to the queue\n", userResponse);
						}
						else {
							printf("%d hasn't been added to the queue\n", userResponse);
						}
					}
					else if (userResponse == 3) {
						printf("The head is:%d\n", pop(userArray, &size, capacity, &head));
					}
					else if (userResponse == 4) {
						printf("The head is:%d\n", peek(userArray, size, capacity, head, tail));
					}
					else if (userResponse == 5) {
						printf("Listing contents of the queue\n\n");
						for (int i = head; i != tail; i++) {
							printf("%d\n", userArray[i]);
						}
					}
				}

				free(userArray);
				done = false;
			}
		}
		else if (userInput == 2) {

			Queue<int> myQueue{10};

			while (!done) {

				int userResponse;
				printf("Queue Status: size:%d, capacity:%d", myQueue.getSize(), myQueue.getCapacity());
				printf("\nWould you like to quit(1), push(2), pop(3), peek(4), list the queue contents(5)?:");
				scanf("%d", &userResponse);
				scanf("%c", &tmp);

				if (userResponse == 1) {
					done = true;
				}
				else if (userResponse == 2) {
					printf("Enter a number to enqueue on the queue:");
					scanf("%d", &userResponse);
					scanf("%c", &tmp);
					
					bool success = myQueue.push(userResponse);

					if (success) {
						printf("%d has been added to the queue\n", userResponse);
					}
					else {
						printf("%d hasn't been added to the queue\n", userResponse);
					}
				}
				else if (userResponse == 3) {
					if (!myQueue.isEmpty())
						printf("The head is:%d\n", myQueue.pop());
					else
						printf("No head to pop\n");
				}
				else if (userResponse == 4) {
					if (!myQueue.isEmpty())
						printf("The head is:%d\n", myQueue.peek());
					else
						printf("No head to peek in on\n");
				}
				else if (userResponse == 5) {
					printf("Listing contents of the queue\n\n");

					for (char tmp : myQueue.toString())
						printf("%c\n", tmp);

					printf("\n");
				}
			}
			
			done = false;
		}
		else if (userInput == 3) {
			done = true;
		}
	}

	return 0;
}