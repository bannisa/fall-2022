


int pop(int* queueArray, int* size, int capacity, int* head);


bool push(int** queueArray,int toPush, int* size, int* capacity, int* head, int* tail);


int peek(int* queueArray, int size, int capacity, int head, int tail);





