#include <stdio.h>
#include "Shape.h"


Shape::Shape()
{
        
}
    
const char* Shape::getType()
{
	return "";
}
    
double Shape::area()
{
	return 0;
}
    
void Shape::print()
{
	printf("The area of the %s is %f\n", getType(), area());
}
    
