#ifndef _Shape

#define _Shape

class Shape 
{
public:
            Shape();
            virtual const char* getType();
            virtual double area();
            virtual void print();
};

#endif