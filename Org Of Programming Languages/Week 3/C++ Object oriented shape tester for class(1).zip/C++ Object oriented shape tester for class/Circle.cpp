#include "Circle.h"
#include "math.h"

const double Circle::pi = 3.14;

Circle::Circle(double radius)
{
   Shape();
   this->radius = radius; 
   
}
    
const char* Circle::getType()
{
    return "Circle";
}
    
double Circle::area()
{
  return pi * pow(radius,2);
}
