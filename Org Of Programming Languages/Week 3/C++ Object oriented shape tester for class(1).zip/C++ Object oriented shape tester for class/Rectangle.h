#include "Shape.h"

class Rectangle : public Shape
{
private:
	 double width;
     double length;
    
public:
	Rectangle(double width, double length);
    const char* getType();
    double area();
};